<?php // Leave empty - just enables PHP processing ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hotel Banyan Paradise Kitchen | Web Project by Dharmik Barot-Vadodara</title>
    <meta name="description" content="Banayan Paradise - Responsive PHP web project by BCA student Dharmik Barot from Vadodara. Features modern UI/UX, galleries, contact forms & SEO optimization.">
     <!-- Open Graph for Social Media Sharing -->
     <meta name="keywords" content="Banayan Paradise, Dharmik Barot, web developer Vadodara, PHP portfolio, BCA project, responsive website, web development Gujarat">
     <meta property="og:title" content="Banayan Paradise | Dharmik Barot Portfolio">
    <meta property="og:description" content="Check out my latest responsive web project - Banayan Paradise! Built with PHP, modern UI/UX.">
    <meta property="og:type" content="website">
    <meta property="og:url" content="https://your-banayanparadise-url.com">
    <meta property="og:image" content="https://your-banayanparadise-url.com/images/og-image.jpg">
        <!-- Twitter Card -->
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="Banayan Paradise | Dharmik Barot">
    <meta name="twitter:description" content="Responsive PHP portfolio project by Vadodara web developer.">
	 <!-- Canonical URL (prevents duplicate content) -->
    <link rel="canonical" href="https://your-banayanparadise-url.com/">
    
    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="/favicon.ico">
    
    <!-- Preload critical resources -->
    <link rel="preload" href="/css/style.css" as="style">
    <link rel="preload" href="/js/main.js" as="script">
    
    <!-- DNS Prefetch for external resources -->
    <link rel="dns-prefetch" href="//fonts.googleapis.com">
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="Hotel/style.css">
		
</head>
<body>
    <!-- BACKGROUND -->
    <div class="bg-gradient"></div>

    <!-- NAVBAR -->
    <nav class="navbar">
        <div class="nav-container">
            <div class="logo">
                <i class="fas fa-hotel"></i>
                Hotel Banyan Paradise Kitchen
            </div>
     <div class="hamburger" onclick="toggleMenu()">
  <span></span>
  <span></span>
  <span></span>
</div>
            <ul class="nav-menu">
                <li><a href="#home" class="nav-link active">Home</a></li>
                <li><a href="#rooms" class="nav-link">Rooms</a></li>
                <li><a href="#facilities" class="nav-link">Facilities</a></li>
                <li><a href="#gallery" class="nav-link">Gallery</a></li>
                <li><a href="#contact" class="nav-link">Contact</a></li>
            </ul>
            <a href="#home" class="cta-btn">Book Now</a>
        </div>
    </nav>

    <!-- HERO SECTION -->
    <section class="hero" id="home">
        <div class="hero-content">
            <div class="hero-text">
                <div class="hero-badge">★ 5-Star Luxury</div>
                <h1 class="hero-title">Welcome to <span>Hotel Banyan Paradise Kitchen</span></h1>
                <p class="hero-subtitle">Experience luxury stay in the heart of Vadodara with world-class hospitality</p>
                <div class="hero-stats">
                    <div class="stat-item">
                        <div class="stat-number">4.9</div>
                        <div class="stat-label">Rating</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-number">500+</div>
                        <div class="stat-label">Happy Guests</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-number">50+</div>
                        <div class="stat-label">Awards</div>
                    </div>
                </div>
            </div>
            <div class="booking-card">
                <div class="booking-header">
                    <div class="booking-badge">Best Price Guarantee</div>
                    <h3>Book Your Stay</h3>
                </div>
 
<form class="booking-form" method="POST" action="Success.php">
   <!-- PERFECT MOBILE BOOKING FORM -->
<div class="booking-card-mobile">
    <div class="booking-header">
        <div class="booking-badge">Best Price Guaranteed</div>
        <h3>Book Your Stay</h3>
    </div>
    <form class="booking-form" method="POST" action="Success.php">
        <!-- DATE FIELDS - NO OVERFLOW -->
        <div class="form-row">
<div class="form-field">
<label>Check-in</label>
<input type="date" name="checkin" required>
</div>
<div class="form-field">
<label>Check-out</label>
<input type="date" name="checkout" required>
</div>
</div>
        
        <div class="form-row">
<div class="form-field">
<label>Guests</label>
<select name="guests" required>
<option value="1">1 Guest</option>
<option value="2">2 Guests</option>
<option value="3">3 Guests</option>
<option value="4">4 Guests</option>
</select>
</div>
<div class="form-field">
<label>Rooms</label>
<select name="rooms" required>
<option value="1">1 Room</option>
<option value="2">2 Rooms</option>
</select>
</div>
</div>
<div class="form-field">
<label>Full Name</label>
<input type="text" name="guest_name" placeholder="Enter your full name" required>
</div>
<div class="form-field">
<label>Email</label>
<input type="email" name="email" placeholder="your@email.com" required>
</div>
<button type="submit" name="submit" class="btn-primary">
<i class="fas fa-calendar-check"></i> Book Now
</button>
</form>
</div>
</div>


    </section>

    <!-- FACILITIES -->
    <section class="facilities" id="facilities">
        <div class="container">
            <h2 class="section-heading">Why Choose Hotel Banyan Paradise Kitchen</h2>
            <p class="section-desc">Experience luxury and comfort with our world-class amenities</p>
            <div class="facilities-grid">
                <div class="facility-card">
                    <i class="fas fa-wifi"></i>
                    <h3>Free WiFi</h3>
                    <p>High-speed internet access throughout the hotel</p>
                </div>
                <div class="facility-card">
                    <i class="fas fa-concierge-bell"></i>
                    <h3>24/7 Room Service</h3>
                    <p>Round-the-clock service for all your needs</p>
                </div>
                <div class="facility-card">
                    <i class="fas fa-utensils"></i>
                    <h3>Multi-Cuisine Restaurant</h3>
                    <p>World-class dining experience</p>
                </div>
                <div class="facility-card">
                    <i class="fas fa-users"></i>
                    <h3>Conference Hall</h3>
                    <p>Perfect for business meetings and events</p>
                </div>
                <div class="facility-card">
                    <i class="fas fa-parking"></i>
                    <h3>Free Parking</h3>
                    <p>Ample parking space for guests</p>
                </div>
                <div class="facility-card">
                    <i class="fas fa-plane"></i>
                    <h3>Airport Pickup</h3>
                    <p>Complimentary airport transfers</p>
                </div>
            </div>
        </div>
    </section>

    <!-- ROOMS -->
    <section class="rooms" id="rooms">
        <div class="container">
            <h2 class="section-heading">Our Luxury Rooms</h2>
            <p class="section-desc">Choose from our premium collection of rooms and suites</p>
            <div class="rooms-grid">
                <div class="room-card">
                    <div class="room-image">
                        <img src="https://images.unsplash.com/photo-1566073771259-6a8506099945?w=500&fit=crop" alt="Deluxe Room" loading="lazy">
                        <div class="room-label">Popular</div>
                    </div>
                    <div class="room-info">
                        <div class="room-header">
                            <h3>Deluxe Room</h3>
                            <div class="room-rating">
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <span>4.9</span>
                            </div>
                        </div>
                        <p>Elegant room with city views, modern amenities, king bed and work desk.</p>
                        <ul class="room-features">
                            <li><i class="fas fa-bed"></i> King Size Bed</li>
                            <li><i class="fas fa-wifi"></i> High Speed WiFi</li>
                            <li><i class="fas fa-tv"></i> Smart TV</li>
                        </ul>
                        <div class="room-footer">
                            <div class="room-price">₹2,500 <span>/night</span></div>
                            <a href="#home" class="btn-secondary">Book Now</a>
                        </div>
                    </div>
                </div>
                <div class="room-card featured">
                    <div class="room-image">
                        <img src="https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=500&fit=crop" alt="Executive Suite" loading="lazy">
                        <div class="room-label featured">Featured</div>
                    </div>
                    <div class="room-info">
                        <div class="room-header">
                            <h3>Executive Suite</h3>
                            <div class="room-rating">
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <span>4.9</span>
                            </div>
                        </div>
                        <p>Luxury suite with separate living area, balcony, and premium amenities.</p>
                        <ul class="room-features">
                            <li><i class="fas fa-bed"></i> 2 King Beds</li>
                            <li><i class="fas fa-couch"></i> Living Room</li>
                            <li><i class="fas fa-bath"></i> Jacuzzi</li>
                        </ul>
                        <div class="room-footer">
                            <div class="room-price">₹4,500 <span>/night</span></div>
                            <a href="#home" class="btn-primary">Book Now</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- GALLERY -->
    <section class="gallery" id="gallery">
        <div class="container">
            <h2 class="section-heading">Gallery</h2>
            <p class="section-desc">A glimpse of luxury awaits</p>
            <div class="gallery-grid">
                <div class="gallery-item">
                    <img src="https://images.unsplash.com/photo-1559599101-f09722fb4948?w=400&fit=crop" alt="Lobby" loading="lazy">
                    <div class="gallery-overlay">
                        <h3>Luxury Lobby</h3>
                    </div>
                </div>
                <div class="gallery-item">
                    <img src="https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?w=400&fit=crop" alt="Restaurant" loading="lazy">
                    <div class="gallery-overlay">
                        <h3>Restaurant</h3>
                    </div>
                </div>
                <div class="gallery-item">
                    <img src="https://images.unsplash.com/photo-1618773928121-c32242e63f39?w=400&fit=crop" alt="Room" loading="lazy">
                    <div class="gallery-overlay">
                        <h3>Premium Room</h3>
                    </div>
                </div>
                <div class="gallery-item">
                    <img src="https://images.unsplash.com/photo-1566073771259-6a8506099945?w=400&fit=crop" alt="Suite" loading="lazy">
                    <div class="gallery-overlay">
                        <h3>Executive Suite</h3>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- CONTACT -->
    <section class="contact" id="contact">
        <div class="container">
            <h2 class="section-heading">Contact Us</h2>
            <p class="section-desc">Ready to book? Get in touch with us</p>
            <div class="contact-grid">
                <div class="contact-info">
                    <div class="info-item">
                        <i class="fas fa-map-marker-alt"></i>
                        <div>
                            <h4>Address</h4>
                            <p>Ashram Road, Vadodara, Gujarat 380009</p>
                        </div>
                    </div>
                    <div class="info-item">
                        <i class="fas fa-phone"></i>
                        <div>
                            <h4>Phone</h4>
                            <p>+91 8128579959</p>
                        </div>
                    </div>
                    <div class="info-item">
                        <i class="fas fa-envelope"></i>
                        <div>
                            <h4>Email</h4>
                            <p>info@hoteltulip.com</p>
                        </div>
                    </div>
                    <div class="info-item">
                        <i class="fas fa-clock"></i>
                        <div>
                            <h4>Hours</h4>
                            <p>Open 24/7</p>
                        </div>
                    </div>
                </div>
                <form class="contact-form">
                    <div class="form-row">
                        <div class="form-field">
                            <label>Name</label>
                            <input type="text" placeholder="Your Name" required>
                        </div>
                        <div class="form-field">
                            <label>Email</label>
                            <input type="email" placeholder="your@email.com" required>
                        </div>
                    </div>
                    <div class="form-field full">
                        <label>Message</label>
                        <textarea placeholder="Tell us about your stay requirements..."></textarea>
                    </div>
                    <button type="submit" class="btn-primary">Send Message</button>
                </form>
            </div>
        </div>
    </section>

    <!-- FOOTER -->
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-brand">
                    <h3><i class="fas fa-hotel"></i> Hotel Banyan Paradise Kitchen</h3>
                    <p align="center">Your premier destination for luxury accommodation in Vadodara, Gujarat.</p>
                    <div class="social-links">
                        <a href="#"><i class="fab fa-facebook-f"></i></a>
                        <a href="#"><i class="fab fa-instagram"></i></a>
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="#"><i class="fab fa-linkedin-in"></i></a>
                    </div>
                </div>
            </div>
            <div class="footer-bottom">
                <p>© 2026 Dharmik Barot. All Rights Reserved | Designed with ❤️ in Vadodara</p>
            </div>
        </div>
    </footer>

    <script src="Hotel/script.js"></script>
    <!-- MOBILE MENU BUTTON (add after .logo in navbar) -->

    <span></span>
    <span></span>
    <span></span>
</div>

<script>
<!--function toggleMenu() {
    document.querySelector('.nav-menu').classList.toggle('active');
    document.querySelector('.hamburger').classList.toggle('active');
}-->
    function toggleMenu() {
    const navMenu = document.querySelector('.nav-menu');
    const hamburger = document.querySelector('.hamburger');
    
    navMenu.classList.toggle('active');
    hamburger.classList.toggle('active');
}

// Close menu when clicking outside
document.addEventListener('click', (e) => {
    const navMenu = document.querySelector('.nav-menu');
    const hamburger = document.querySelector('.hamburger');
    const navbar = document.querySelector('.navbar');
    
    if (!navbar.contains(e.target)) {
        navMenu.classList.remove('active');
        hamburger.classList.remove('active');
    }
});
</script>
</body>
</html>
