<?php
$host = "";        // <-- from InfinityFree
$user = "";            // <-- from InfinityFree
$pass = "";        // <-- from InfinityFree
$db   = "";      // <-- from InfinityFree

$conn = mysqli_connect($host, $user, $pass, $db);

if (!$conn) {
    die("Database Connection Failed: " . mysqli_connect_error());
}
?>