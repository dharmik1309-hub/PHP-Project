CREATE DATABASE hotel_tulip;

USE hotel_tulip;

CREATE TABLE bookings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    checkin DATE,
    checkout DATE,
    guests INT,
    name VARCHAR(100),
    email VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE admin (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50),
    password VARCHAR(255)
);

INSERT INTO admin (username, password)
VALUES ('admin', MD5('admin123'));