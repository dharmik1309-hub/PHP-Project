<?php
include "config.php";

$checkin  = $_POST['checkin'];
$checkout = $_POST['checkout'];
$guests   = $_POST['guests'];
$name     = $_POST['name'];
$email    = $_POST['email'];

$query = "INSERT INTO bookings (checkin, checkout, guests, name, email)
VALUES ('$checkin','$checkout','$guests','$name','$email')";

mysqli_query($conn, $query);

echo "<h2>Booking Confirmed!</h2>";
echo "<p>Thank you, $name. We will contact you soon.</p>";
?>