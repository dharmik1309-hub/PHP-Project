<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}
include "../config.php";

/* MONTHLY REVENUE */
$months = [];
$revenue = [];

$q = mysqli_query($conn,"
    SELECT MONTH(created_at) m, SUM(total_amount) r
    FROM bookings
    WHERE LOWER(TRIM(COALESCE(payment_status,'')))='paid'
    GROUP BY MONTH(created_at)
");

while ($row = mysqli_fetch_assoc($q)) {
    $months[] = date("M", mktime(0,0,0,$row['m'],1));
    $revenue[] = $row['r'];
}

/* PAYMENT COUNTS */
$paid = mysqli_fetch_assoc(mysqli_query($conn,"
    SELECT COUNT(*) c 
    FROM bookings 
    WHERE LOWER(TRIM(COALESCE(payment_status,'')))='paid'
"))['c'];

$pending = mysqli_fetch_assoc(mysqli_query($conn,"
    SELECT COUNT(*) c 
    FROM bookings 
    WHERE LOWER(TRIM(COALESCE(payment_status,'')))='pending'
"))['c'];
?>
<!DOCTYPE html>
<html>
<head>
<title>Reports | Hotel Tulip</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<style>
:root{
    --bg:#f4f7fb;
    --card:#ffffff;
    --text:#2c3e50;
    --accent:#2563eb;
}
.dark{
    --bg:#0f172a;
    --card:#1e293b;
    --text:#e5e7eb;
    --accent:#22c55e;
}
*{transition:.3s}
body{
    margin:0;font-family:Segoe UI;
    background:var(--bg);color:var(--text);
}

/* SIDEBAR */
.sidebar{
    width:210px;height:100vh;
    background:linear-gradient(180deg,#1e3c72,#2563eb);
    position:fixed;color:#fff
}
.sidebar h2{text-align:center;padding:20px}
.sidebar a{
    display:block;padding:12px 22px;
    color:#fff;text-decoration:none
}
.sidebar a:hover{background:rgba(255,255,255,.15)}

/* MAIN */
.main{margin-left:210px;padding:20px}

/* TOPBAR */
.topbar{
    background:var(--card);
    padding:14px 20px;
    border-radius:12px;
    display:flex;justify-content:space-between;
    box-shadow:0 8px 20px rgba(0,0,0,.08)
}

/* CARDS */
.cards{
    display:flex;gap:20px;margin-top:25px
}
.card{
    background:var(--card);
    padding:18px;
    width:160px;
    border-radius:14px;
    text-align:center;
    box-shadow:0 8px 20px rgba(0,0,0,.08);
    animation:up .5s ease
}
.card h3{margin:0;font-size:26px;color:var(--accent)}
.card p{margin-top:5px;font-size:13px}

/* CHART */
.chart{
    margin-top:30px;
    background:var(--card);
    padding:18px;border-radius:14px;
    box-shadow:0 8px 20px rgba(0,0,0,.08);
    animation:up .7s ease
}
canvas{max-height:200px}

.btn{
    padding:8px 14px;border:none;
    border-radius:8px;
    background:var(--accent);
    color:#fff;cursor:pointer
}

@keyframes up{
    from{opacity:0;transform:translateY(20px)}
    to{opacity:1;transform:translateY(0)}
}

@media print{
    .sidebar,.btn{display:none}
    body{background:#fff}
}
</style>
</head>

<body>

<div class="sidebar">
    <h2>Hotel Tulip</h2>
    <a href="dashboard.php">🏠 Dashboard</a>
    <a href="bookings.php">📅 Bookings</a>
    <a href="reports.php">📊 Reports</a>
</div>

<div class="main">

<div class="topbar">
    <h3>Reports</h3>
    <div>
        <button class="btn" onclick="toggle()">🌙</button>
        <button class="btn" onclick="window.print()">📄</button>
    </div>
</div>

<div class="cards">
    <div class="card">
        <h3><?= $paid ?></h3>
        <p>Paid</p>
    </div>
    <div class="card">
        <h3><?= $pending ?></h3>
        <p>Pending</p>
    </div>
</div>

<div class="chart">
    <h4>Monthly Revenue</h4>
    <canvas id="rev"></canvas>
</div>

<div class="chart">
    <h4>Payment Status</h4>
    <canvas id="status"></canvas>
</div>

</div>

<script>
/* DARK MODE */
if(localStorage.getItem('mode')==='dark')
    document.body.classList.add('dark');

function toggle(){
    document.body.classList.toggle('dark');
    localStorage.setItem('mode',
        document.body.classList.contains('dark')?'dark':'light'
    );
}

/* LINE CHART */
new Chart(document.getElementById('rev'),{
    type:'line',
    data:{
        labels:<?= json_encode($months) ?>,
        datasets:[{
            data:<?= json_encode($revenue) ?>,
            borderColor:'#22c55e',
            backgroundColor:'rgba(34,197,94,.25)',
            fill:true,
            tension:.4
        }]
    },
    options:{plugins:{legend:{display:false}}}
});

/* DOUGHNUT */
new Chart(document.getElementById('status'),{
    type:'doughnut',
    data:{
        labels:['Paid','Pending'],
        datasets:[{
            data:[<?= $paid ?>,<?= $pending ?>],
            backgroundColor:['#22c55e','#f59e0b']
        }]
    },
    options:{
        cutout:'70%',
        plugins:{legend:{position:'bottom'}}
    }
});
</script>

</body>
</html>