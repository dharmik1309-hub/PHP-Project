<?php
session_start();
if(!isset($_SESSION['admin'])){ header("Location: login.php"); exit(); }
include "../config.php";
?>
<!DOCTYPE html>
<html>
<head>
<title>Bookings | Hotel Tulip</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body{margin:0;font-family:Segoe UI;background:#f4f7fb}
.container{padding:30px}
h2{color:#2563eb}

table{
    width:100%;background:#fff;border-radius:12px;
    border-collapse:collapse;overflow:hidden;
    animation:fade .6s ease
}
th,td{padding:12px;text-align:center;border-bottom:1px solid #eee}
th{background:#2563eb;color:#fff}
tr:hover{background:#f1f5ff}

.badge{
    padding:5px 12px;border-radius:20px;
    font-size:12px;font-weight:bold
}
.paid{background:#dcfce7;color:#22c55e}
.pending{background:#fff7ed;color:#f59e0b}

.action a{margin:0 6px;text-decoration:none;font-weight:bold}
.edit{color:#2563eb}
.delete{color:#ef4444}
.invoice{color:#22c55e}

@keyframes fade{
    from{opacity:0;transform:translateY(15px)}
    to{opacity:1;transform:none}
}
</style>
</head>

<body>
<div class="container">
<a href="dashboard.php" class="back-btn">← Back to Dashboard</a>
<h2>📅 Bookings</h2>

<table>
<tr>
<th>ID</th><th>Guest</th><th>Email</th>
<th>Amount</th><th>Status</th><th>Actions</th>
</tr>

<?php
$q=mysqli_query($conn,"SELECT * FROM bookings ORDER BY created_at DESC");
while($b=mysqli_fetch_assoc($q)){
$status=strtolower(trim($b['payment_status']));
?>
<tr>
<td>#<?= $b['id'] ?></td>
<td><?= $b['guest_name'] ?></td>
<td><?= $b['email'] ?></td>
<td>₹<?= $b['total_amount'] ?></td>
<td><span class="badge <?= $status ?>"><?= ucfirst($status) ?></span></td>
<td class="action">
<a class="edit" href="edit_booking.php?id=<?= $b['id'] ?>">✏</a>
<a class="delete" onclick="return confirm('Delete booking?')"
   href="delete_booking.php?id=<?= $b['id'] ?>">🗑</a>
<a class="invoice" target="_blank"
   href="invoice.php?id=<?= $b['id'] ?>">🧾</a>
</td>
</tr>
<?php } ?>
</table>
</div>
</body>
</html>