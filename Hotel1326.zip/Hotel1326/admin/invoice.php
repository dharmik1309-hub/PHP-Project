<?php
include "../config.php";

/* STEP 1: Check ID */
if (!isset($_GET['id']) || empty($_GET['id'])) {
    die("<h2 style='text-align:center;color:red'>❌ Invalid Invoice Request</h2>");
}

$id = intval($_GET['id']); // security

/* STEP 2: Fetch Data */
$query = "SELECT * FROM bookings WHERE id = $id";
$result = mysqli_query($conn, $query);

if (mysqli_num_rows($result) == 0) {
    die("<h2 style='text-align:center;color:red'>❌ Invoice Not Found</h2>");
}

$data = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html>
<head>
<title>Hotel Tulip Invoice</title>

<style>
body{
    font-family: 'Segoe UI', sans-serif;
    background:#f4f6f9;
}

.invoice{
    width:650px;
    margin:50px auto;
    background:#fff;
    padding:30px;
    border-radius:12px;
    box-shadow:0 15px 30px rgba(0,0,0,0.15);
}

.invoice h1{
    text-align:center;
    color:#1e3c72;
    margin-bottom:10px;
}

.invoice hr{
    border:0;
    height:2px;
    background:#1e3c72;
    margin:15px 0;
}

.invoice p{
    font-size:16px;
    margin:8px 0;
}

.label{
    font-weight:600;
    color:#333;
}

.total{
    font-size:22px;
    font-weight:bold;
    color:#0b8457;
    margin-top:20px;
}

.actions{
    margin-top:25px;
    text-align:center;
}

button{
    padding:10px 20px;
    font-size:15px;
    border:none;
    border-radius:6px;
    background:#1e3c72;
    color:#fff;
    cursor:pointer;
}

button:hover{
    background:#16315d;
}

.back{
    display:inline-block;
    margin-top:15px;
    text-decoration:none;
    color:#555;
}
</style>
</head>

<body>

<div class="invoice">
    <h1>Hotel Tulip Invoice</h1>
    <hr>

    <p><span class="label">Invoice ID:</span> #<?php echo $data['id']; ?></p>
    <p><span class="label">Guest Name:</span> <?php echo $data['guest_name']; ?></p>
    <p><span class="label">Email:</span> <?php echo $data['email']; ?></p>
    <p><span class="label">Check-in:</span> <?php echo $data['checkin']; ?></p>
    <p><span class="label">Check-out:</span> <?php echo $data['checkout']; ?></p>
    <p><span class="label">Payment Mode:</span> <?php echo $data['payment_mode']; ?></p>

    <p class="total">Total Amount: ₹<?php echo $data['total_amount']; ?></p>

    <div class="actions">
        <button onclick="window.print()">🖨 Print Invoice</button><br>
        <a class="back" href="dashboard.php">⬅ Back to Dashboard</a>
    </div>
</div>

</body>
</html>