<?php
session_start();
if(!isset($_SESSION['admin'])){
    header("Location: login.php");
    exit();
}

include "../config.php";

if(!isset($_GET['id'])){
    header("Location: ../rooms.php");
    exit();
}

$id = intval($_GET['id']);

// Fetch room data
$res = mysqli_query($conn, "SELECT * FROM rooms WHERE id=$id");
$room = mysqli_fetch_assoc($res);

if(!$room){
    die("Room not found");
}

// Update room
if(isset($_POST['update'])){
    $type  = mysqli_real_escape_string($conn, $_POST['room_type']);
    $price = mysqli_real_escape_string($conn, $_POST['price_per_night']);

    mysqli_query($conn, "
        UPDATE rooms 
        SET room_type='$type', price_per_night='$price'
        WHERE id=$id
    ");

    header("Location: rooms.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Edit Room | Hotel Tulip</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body{font-family:Segoe UI;background:#f4f7fb;margin:0}
.box{
    max-width:420px;
    background:#fff;
    margin:60px auto;
    padding:30px;
    border-radius:12px;
    box-shadow:0 10px 30px rgba(0,0,0,0.1)
}
h2{text-align:center;color:#2563eb}
input,button{
    width:100%;
    padding:12px;
    margin:10px 0;
    border-radius:8px;
    border:1px solid #ddd;
    font-size:14px
}
button{
    background:#2563eb;
    color:#fff;
    border:none;
    cursor:pointer;
    font-weight:bold
}
button:hover{background:#1e40af}
a{text-decoration:none;color:#2563eb;font-weight:bold}
</style>
</head>

<body>
<div class="box">
<h2>Edit Room</h2>

<form method="POST">
    <input type="text" name="room_type" value="<?= $room['room_type'] ?>" required>
    <input type="number" name="price_per_night" value="<?= $room['price_per_night'] ?>" required>
    <button name="update">Update Room</button>
</form>

<p style="text-align:center;margin-top:10px;">
<a href="Rooms.php">← Back</a>
</p>
</div>
</body>
</html>