<?php
session_start();
if(!isset($_SESSION['admin'])){ header("Location: login.php"); exit(); }
include "../config.php";
?>
<!DOCTYPE html>
<html>
<head>
<title>Customers | Hotel Tulip</title>
<style>
body{margin:0;font-family:Segoe UI;background:#f4f7fb}
.container{padding:30px}
h2{color:#2563eb}

table{
    width:100%;background:#fff;border-radius:12px;
    border-collapse:collapse;overflow:hidden;
    animation:fade .6s ease
}
th,td{padding:12px;text-align:center;border-bottom:1px solid #eee}
th{background:#2563eb;color:#fff}
tr:hover{background:#f1f5ff}

.delete{color:#ef4444;font-weight:bold;text-decoration:none}

@keyframes fade{
    from{opacity:0;transform:translateY(15px)}
    to{opacity:1}
}
</style>
</head>

<body>
<div class="container">
    <a href="dashboard.php" class="back-btn">← Back to Dashboard</a>
<h2>👤 Customers</h2>

<table>
<tr>
<th>#</th><th>Name</th><th>Email</th><th>Bookings</th>
</tr>

<?php
$q=mysqli_query($conn,"
SELECT guest_name,email,COUNT(*) total
FROM bookings GROUP BY email
");
$i=1;
while($c=mysqli_fetch_assoc($q)){
?>
<tr>
<td><?= $i++ ?></td>
<td><?= $c['guest_name'] ?></td>
<td><?= $c['email'] ?></td>
<td><?= $c['total'] ?></td>
</tr>
<?php } ?>
</table>
</div>
</body>
</html>