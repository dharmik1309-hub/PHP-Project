<?php
    error_reporting(E_ALL);
ini_set('display_errors', 1);


include "../config.php";
session_start();


$error = "";

if (isset($_POST['login'])) {
    $user = mysqli_real_escape_string($conn, $_POST['username']);
    $pass = md5($_POST['password']);

    $res = mysqli_query(
        $conn,
        "SELECT * FROM admin WHERE username='$user' AND password='$pass'"
    );

    if (mysqli_num_rows($res) == 1) {
        $_SESSION[''] = $user;
        header("Location: dashboard.php");
        exit();
    } else {
        $error = "Invalid Username or Password";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Login | Hotel Tulip</title>

    <style>
        body {
            margin: 0;
            font-family: 'Segoe UI', sans-serif;
            height: 100vh;
            background: linear-gradient(120deg, #1e3c72, #2a5298);
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .login-box {
            width: 380px;
            padding: 35px;
            background: rgba(255, 255, 255, 0.15);
            backdrop-filter: blur(10px);
            border-radius: 14px;
            box-shadow: 0 15px 35px rgba(0,0,0,0.35);
            color: #fff;
        }

        .login-box h2 {
            text-align: center;
            margin-bottom: 25px;
            letter-spacing: 1px;
        }

        .login-box input {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            border: none;
            border-radius: 6px;
            outline: none;
            font-size: 14px;
        }

        .login-box button {
            width: 100%;
            padding: 12px;
            border: none;
            border-radius: 6px;
            background: #ffcc00;
            color: #000;
            font-size: 16px;
            cursor: pointer;
            margin-top: 15px;
            font-weight: bold;
        }

        .login-box button:hover {
            background: #ffd633;
        }

        .error {
            background: rgba(255,0,0,0.2);
            padding: 10px;
            border-radius: 6px;
            text-align: center;
            margin-bottom: 10px;
            font-size: 14px;
        }

        .footer-text {
            text-align: center;
            margin-top: 15px;
            font-size: 13px;
            opacity: 0.8;
        }
    </style>
</head>

<body>

<div class="login-box">
    <h2>Hotel Tulip Admin</h2>

    <?php if ($error != "") { ?>
        <div class="error"><?php echo $error; ?></div>
    <?php } ?>

    <form method="POST">
        <input type="text" name="username" placeholder="Username" required>
        <input type="password" name="password" placeholder="Password" required>
        <button type="submit" name="login">Login</button>
    </form>

    <div class="footer-text">
        Secure Admin Access
    </div>
</div>

</body>
</html>