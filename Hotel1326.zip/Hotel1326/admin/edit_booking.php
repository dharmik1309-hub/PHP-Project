<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

include "../config.php";

// SECURE ID SANITIZATION
$id = intval($_GET['id']); // CONVERT TO INTEGER

// FETCH DATA SECURELY
$stmt = $conn->prepare("SELECT * FROM bookings WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$data = $result->fetch_assoc();

if (!$data) {
    header("Location: dashboard.php?error=notfound");
    exit();
}

if (isset($_POST['update'])) {
    $status = $_POST['payment_status'];
    $mode = $_POST['payment_mode'];

    // UPDATE WITH PREPARED STATEMENT
    $updateStmt = $conn->prepare("UPDATE bookings SET payment_status = ?, payment_mode = ? WHERE id = ?");
    $updateStmt->bind_param("ssi", $status, $mode, $id);
    
    if ($updateStmt->execute()) {
        header("Location: dashboard.php?msg=updated&id=" . $id);
        exit();
    } else {
        $error = "Update failed: " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Edit Booking #<?php echo $id; ?></title>
<style>
body{font-family:Segoe UI;background:#f4f6f9;padding:20px}
.box{
    width:480px;max-width:90vw;margin:50px auto;
    background:#fff;padding:35px;border-radius:20px;
    box-shadow:0 20px 40px rgba(0,0,0,.1)
}
h2{margin:0 0 25px;color:#1e3c72;text-align:center;font-size:24px}
.guest-info{padding:15px;background:#f8fafc;border-radius:10px;margin-bottom:25px}
label{display:block;margin:20px 0 8px;font-weight:600;color:#374151;font-size:15px}
select,button{
    width:100%;padding:14px 16px;
    border:2px solid #e5e7eb;border-radius:10px;
    font-family:Segoe UI;font-size:16px;box-sizing:border-box
}
select{background:#f9fafb;color:#374151}
select:focus{outline:none;border-color:#3b82f6;box-shadow:0 0 0 3px rgba(59,130,246,.1)}
button{
    background:linear-gradient(135deg,#3b82f6,#1d4ed8);
    color:#fff;border:none;font-weight:700;
    cursor:pointer;transition:all .3s;font-size:16px;
    margin-top:25px;height:50px;border-radius:12px
}
button:hover{transform:translateY(-2px);box-shadow:0 15px 30px rgba(59,130,246,.4)}
.back-btn{display:inline-block;margin-top:20px;padding:10px 20px;background:#6b7280;color:#fff;text-decoration:none;border-radius:8px;transition:all .3s}
.back-btn:hover{background:#4b5563;transform:translateY(-1px)}
.error{background:#fee2e2;border:1px solid #fecaca;color:#dc2626;padding:12px;border-radius:8px;margin:15px 0}
</style>
</head>
<body>
<div class="box">
    <h2>✏️ Edit Booking #<?php echo $id; ?></h2>
    
    <div class="guest-info">
        <strong>👤 Guest:</strong> <?php echo htmlspecialchars($data['guest_name']); ?><br>
        <strong>📧 Email:</strong> <?php echo htmlspecialchars($data['email']); ?><br>
        <strong>💰 Amount:</strong> ₹<?php echo number_format($data['total_amount']); ?>
    </div>

    <?php if(isset($error)): ?>
        <div class="error"><?php echo $error; ?></div>
    <?php endif; ?>

    <form method="POST">
        <label>💳 Payment Status</label>
        <select name="payment_status" required>
            <option value="Paid" <?php if($data['payment_status'] == "Paid") echo "selected"; ?>>✅ Paid</option>
            <option value="Pending" <?php if($data['payment_status'] == "Pending") echo "selected"; ?>>⏳ Pending</option>
        </select>

        <label>💵 Payment Mode</label>
        <select name="payment_mode" required>
            <option value="Cash" <?php if(($data['payment_mode'] ?? '') == "Cash") echo "selected"; ?>>💰 Cash</option>
            <option value="UPI" <?php if(($data['payment_mode'] ?? '') == "UPI") echo "selected"; ?>>📱 UPI</option>
            <option value="Card" <?php if(($data['payment_mode'] ?? '') == "Card") echo "selected"; ?>>💳 Card</option>
            <option value="Bank Transfer" <?php if(($data['payment_mode'] ?? '') == "Bank Transfer") echo "selected"; ?>>🏦 Bank Transfer</option>
        </select>

        <button name="update">💾 Update Booking</button>
    </form>

    <a href="dashboard.php" class="back-btn">← Back to Dashboard</a>
</div>
</body>
</html>
