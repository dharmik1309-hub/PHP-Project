<?php
session_start();
if(!isset($_SESSION['admin'])){
    header("Location: login.php");
    exit();
}
include "../config.php";
?>
<!DOCTYPE html>
<html>
<head>
<title>Rooms | Hotel Tulip</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<style>
body{
    margin:0;
    font-family:Segoe UI;
    background:#f0f4f8;
}
.container{
    padding:30px;
    animation:fadeIn 0.6s ease;
}
h2{color:#2563eb}

/* Table */
table{
    width:100%;
    background:#fff;
    border-radius:12px;
    border-collapse:collapse;
    overflow:hidden;
    box-shadow:0 8px 20px rgba(0,0,0,0.05);
}
th,td{
    padding:14px;
    text-align:center;
    border-bottom:1px solid #eee;
}
th{
    background:#2563eb;
    color:#fff;
    text-transform:uppercase;
    letter-spacing:0.5px;
}
tr:hover{background:#e0e7ff; transition:0.3s;}

/* Cards */
.card{
    background:#fff;
    padding:20px;
    border-radius:12px;
    text-align:center;
    box-shadow:0 10px 25px rgba(0,0,0,0.08);
    transition: transform 0.3s;
}
.card:hover{
    transform: translateY(-5px);
}

/* Status badges */
.status{
    padding:6px 12px;
    border-radius:8px;
    color:#fff;
    font-weight:bold;
    display:inline-block;
}
.available{background:#22c55e;}
.booked{background:#ef4444;}

/* Action buttons */
.action a{
    margin:0 6px;
    text-decoration:none;
    font-weight:bold;
    transition:0.3s;
}
.edit{color:#2563eb;}
.edit:hover{color:#1e40af;}
.delete{color:#ef4444;}
.delete:hover{color:#b91c1c;}

/* Animations */
@keyframes fadeIn{
    from{opacity:0; transform:translateY(20px);}
    to{opacity:1; transform:translateY(0);}
}
.success-msg{
    background:#dcfce7;
    color:#166534;
    padding:12px;
    margin-bottom:15px;
    border-radius:8px;
    font-weight:600;
}
</style>
</head>
<body>

<div class="container">
    <?php if(isset($_GET['updated'])): ?>
    <div class="success-msg">✅ Room updated successfully</div>
<?php endif; ?>
<a href="dashboard.php" class="back-btn">← Back to Dashboard</a>
<h2>🛏 Rooms</h2>

<table>
<tr>
<th>ID</th>
<th>Room Type</th>
<th>Price / Night</th>
<th>Actions</th>
</tr>

<?php
$q = mysqli_query($conn,"SELECT * FROM rooms ORDER BY id DESC");
while($r = mysqli_fetch_assoc($q)):
?>
<tr>
<td>#<?= $r['id'] ?></td>
<td><?= $r['room_type'] ?></td>
<td>₹<?= $r['price_per_night'] ?></td>
<td class="action">
    <a class="edit" href="edit_room.php?id=<?= $r['id'] ?>">✏ Edit</a>
    <a class="delete" onclick="return confirm('Delete this room?')"
       href="delete_room.php?id=<?= $r['id'] ?>">🗑 Delete</a>
</td>
</tr>
<?php endwhile; ?>

</table>
</div>

</body>
</html>