<?php
session_start();
if(!isset($_SESSION['admin'])){
    header("Location: login.php");
    exit();
}

include "../config.php";

if(!isset($_GET['id'])){
    header("Location: Rooms.php");
    exit();
}

$id = intval($_GET['id']);

mysqli_query($conn, "DELETE FROM rooms WHERE id=$id");

header("Location: Rooms.php");
exit();