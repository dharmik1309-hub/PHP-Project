<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}
include "../config.php";

// DASHBOARD STATS
$totalBookings = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM bookings"))['total'];
$totalRooms = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS rooms FROM rooms"))['rooms'] ?? 10;
$totalRevenue = mysqli_fetch_assoc(mysqli_query($conn, "SELECT SUM(total_amount) AS revenue FROM bookings WHERE payment_status='Paid'"))['revenue'] ?? 0;
$pendingPayments = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS pending FROM bookings WHERE payment_status='Pending'"))['pending'] ?? 0;

$successMsg = '';
if (isset($_GET['msg']) && $_GET['msg'] == 'updated') {
    $successMsg = '<div class="alert alert-success">✅ Booking updated successfully!</div>';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Admin Dashboard | Hotel Banyan Paradise Kitchen</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* RESET */
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: 'Segoe UI', Tahoma, sans-serif; 
            background: #f8fafc; line-height: 1.6;
        }

        /* SIDEBAR - FIXED POSITION */
        .sidebar {
            position: fixed; 
            left: 0; top: 0; 
            width: 260px; height: 100vh;
            background: linear-gradient(180deg, #1e3c72 0%, #2a5298 100%);
            color: white; 
            z-index: 1000;
            overflow-y: auto;
            box-shadow: 2px 0 15px rgba(0,0,0,0.1);
        }
        
        .sidebar-header {
            padding: 30px 20px 20px;
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        .sidebar-header h2 { 
            font-size: 22px; font-weight: 700; margin: 0;
            background: linear-gradient(135deg, #fff 0%, #f0f9ff 100%);
            -webkit-background-clip: text; -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .sidebar-menu {
            list-style: none; padding: 10px 0;
        }
        .sidebar-menu li a {
            display: flex; align-items: center;
            padding: 16px 25px; 
            color: rgba(255,255,255,0.9); 
            text-decoration: none;
            font-weight: 500; 
            transition: all 0.3s ease;
            border-left: 3px solid transparent;
        }
        .sidebar-menu li a:hover, .sidebar-menu li a.active {
            background: rgba(255,255,255,0.15);
            color: white; border-left-color: #ffd700;
            transform: translateX(3px);
        }
        .sidebar-menu i { 
            width: 22px; margin-right: 15px; font-size: 18px; 
        }

        /* MAIN CONTENT - PROPER SPACING */
        .main-content {
            margin-left: 260px; 
            min-height: 100vh;
            background: #f8fafc;
        }

        /* TOPBAR */
        .topbar {
            background: white;
            padding: 25px 35px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky; top: 0; z-index: 999;
        }
        .topbar h1 { 
            font-size: 28px; 
            background: linear-gradient(135deg, #1e3c72, #2a5298);
            -webkit-background-clip: text; 
            -webkit-text-fill-color: transparent;
            margin: 0; font-weight: 700;
        }
        .user-greeting {
            font-size: 16px; color: #64748b; font-weight: 500;
        }
        .logout-btn {
            background: linear-gradient(135deg, #ef4444, #dc2626);
            color: white; padding: 12px 25px;
            border-radius: 25px; text-decoration: none;
            font-weight: 600; transition: all 0.3s;
            box-shadow: 0 4px 15px rgba(239,68,68,0.2);
        }
        .logout-btn:hover { 
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(239,68,68,0.3);
        }

        /* CONTENT */
        .content {
            padding: 40px; max-width: 1400px; margin: 0 auto;
        }
        .content h2 {
            font-size: 32px; color: #1e3c72;
            margin-bottom: 30px; font-weight: 700;
            display: flex; align-items: center; gap: 12px;
        }

        /* ALERT */
        .alert {
            padding: 20px 25px; margin-bottom: 30px;
            border-radius: 12px; font-weight: 500;
            box-shadow: 0 4px 15px rgba(0,0,0,0.08);
        }
        .alert-success {
            background: linear-gradient(135deg, #d4edda, #c3e6cb);
            color: #155724; border-left: 5px solid #28a745;
        }

        /* STATS CARDS */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 25px; margin-bottom: 50px;
        }
        .stat-card {
            background: white;
            padding: 35px 30px;
            border-radius: 20px;
            text-align: center;
            box-shadow: 0 10px 40px rgba(0,0,0,0.08);
            transition: all 0.3s ease;
            border: 1px solid #f1f5f9;
            position: relative;
        }
        .stat-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 25px 60px rgba(0,0,0,0.15);
        }
        .stat-card::before {
            content: '';
            position: absolute; top: 0; left: 0; right: 0;
            height: 4px; background: linear-gradient(90deg, #1e3c72, #2a5298);
        }
        .stat-card.revenue::before { 
            background: linear-gradient(90deg, #10b981, #34d399); 
        }
        .stat-card.pending::before { 
            background: linear-gradient(90deg, #ef4444, #f87171); 
        }
        .stat-label { 
            color: #64748b; font-size: 15px; 
            font-weight: 600; margin-bottom: 15px;
            text-transform: uppercase; letter-spacing: 0.5px;
        }
        .stat-value { 
            font-size: 42px; font-weight: 800; margin: 0;
            line-height: 1.1;
        }
        .stat-card .stat-value { color: #1e3c72; }
        .stat-card.revenue .stat-value { color: #10b981; }
        .stat-card.pending .stat-value { color: #ef4444; }

        /* TABLE */
        .table-container {
            background: white;
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 15px 50px rgba(0,0,0,0.1);
            margin-bottom: 50px;
        }
        table { 
            width: 100%; 
            border-collapse: collapse; 
        }
        th {
            background: linear-gradient(135deg, #1e3c72, #2a5298);
            color: white; padding: 20px 15px;
            font-weight: 600; text-align: center;
            font-size: 13px; text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        td {
            padding: 20px 15px;
            text-align: center; 
            vertical-align: middle;
            border-bottom: 1px solid #f1f5f9;
        }
        tr:hover { background: #f8fafc; }

        .status-badge {
            padding: 6px 16px; border-radius: 20px;
            font-size: 12px; font-weight: 700; text-transform: uppercase;
        }
        .status-badge.paid { 
            background: rgba(16,185,129,0.1); color: #10b981; 
        }
        .status-badge.pending { 
            background: rgba(239,68,68,0.1); color: #ef4444; 
        }

        /* ACTION BUTTONS */
        .action-buttons {
            display: flex; gap: 8px;
            flex-wrap: wrap; justify-content: center;
        }
        .action-btn {
            padding: 10px 20px; border-radius: 10px;
            text-decoration: none; font-weight: 600;
            font-size: 13px; transition: all 0.3s;
            display: inline-flex; align-items: center; gap: 6px;
            min-height: 42px;
        }
        .action-btn.edit { 
            background: linear-gradient(135deg, #3b82f6, #2563eb);
            color: white;
        }
        .action-btn.delete { 
            background: linear-gradient(135deg, #ef4444, #dc2626);
            color: white;
        }
        .action-btn.invoice { 
            background: linear-gradient(135deg, #10b981, #059669);
            color: white;
        }
        .action-btn:hover { transform: translateY(-2px); }

        /* FOOTER */
        .footer {
            text-align: center; padding: 40px 20px;
            color: #94a3b8; font-size: 15px;
            background: white; border-radius: 16px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.05);
        }

        /* MOBILE RESPONSIVE */
        @media (max-width: 1200px) {
            .stats-grid { grid-template-columns: repeat(2, 1fr); }
        }

        @media (max-width: 992px) {
            .sidebar { transform: translateX(-100%); }
            .sidebar.open { transform: translateX(0); }
            .main-content { margin-left: 0 !important; }
            .hamburger { display: block !important; }
        }

        @media (max-width: 768px) {
            .topbar { padding: 20px 25px; }
            .topbar h1 { font-size: 24px; }
            .content { padding: 25px 20px; }
            .stats-grid { 
                grid-template-columns: 1fr; gap: 20px;
            }
            .stat-value { font-size: 36px; }
            th, td { padding: 16px 12px; font-size: 13px; }
            .action-buttons { flex-direction: column; }
            .action-btn { width: 100%; max-width: 140px; }
        }

        @media (max-width: 480px) {
            .content { padding: 20px 15px; }
            .table-container { margin: 0 -15px 30px; border-radius: 0; }
        }

        /* HAMBURGER */
        .hamburger {
            display: none;
            position: fixed; top: 25px; left: 20px;
            background: white; border: none;
            border-radius: 12px; width: 50px; height: 50px;
            z-index: 1001; cursor: pointer; font-size: 20px;
            color: #1e3c72; box-shadow: 0 5px 20px rgba(0,0,0,0.15);
        }

        /* OVERLAY */
        .sidebar-overlay {
            position: fixed; top: 0; left: 0;
            width: 100%; height: 100vh;
            background: rgba(0,0,0,0.5);
            z-index: 999; opacity: 0; visibility: hidden;
            transition: all 0.3s ease;
        }
        .sidebar-overlay.active { opacity: 1; visibility: visible; }
        /* 🔥 TABLE FIX - SHOW ALL COLUMNS */
.table-container {
    overflow-x: auto !important; /* Horizontal scroll on small screens */
    -webkit-overflow-scrolling: touch;
}

table {
    min-width: 1000px !important; /* Force minimum width */
    table-layout: fixed !important; /* Fixed column widths */
}

th, td {
    width: auto !important;
    min-width: 80px !important; /* Minimum column width */
    max-width: 150px !important;
    overflow: hidden !important;
    text-overflow: ellipsis !important;
    white-space: nowrap !important;
    padding: 15px 8px !important; /* Reduced padding */
}

/* SPECIFIC COLUMN WIDTHS */
th:nth-child(1), td:nth-child(1) { width: 60px !important; } /* ID */
th:nth-child(2), td:nth-child(2) { width: 120px !important; } /* Guest */
th:nth-child(3), td:nth-child(3) { width: 140px !important; } /* Email */
th:nth-child(4), td:nth-child(4) { width: 90px !important; } /* Check-in */
th:nth-child(5), td:nth-child(5) { width: 90px !important; } /* Check-out */
th:nth-child(6), td:nth-child(6) { width: 100px !important; } /* Amount */
th:nth-child(7), td:nth-child(7) { width: 90px !important; } /* Mode */
th:nth-child(8), td:nth-child(8) { width: 90px !important; } /* Status */
th:nth-child(9), td:nth-child(9) { width: 80px !important; } /* Date */
th:nth-child(10), td:nth-child(10) { width: 200px !important; } /* Actions */

/* MOBILE TABLE */
@media (max-width: 768px) {
    table { min-width: 800px !important; }
    .table-container { margin: 0 -15px !important; border-radius: 0 !important; }
    th, td { padding: 12px 6px !important; font-size: 12px !important; }
}
        .truncate {
    max-width: 140px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}
    </style>
</head>

<body>
    <!-- HAMBURGER -->
    <button class="hamburger" onclick="toggleSidebar()">
        <i class="fas fa-bars"></i>
    </button>

    <!-- OVERLAY -->
    <div class="sidebar-overlay" onclick="toggleSidebar()"></div>

    <!-- SIDEBAR -->
    <div class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <h2>🌷 Hotel Banyan Paradise Kitchen</h2>
        </div>
        <ul class="sidebar-menu">
            <li><a href="dashboard.php" class="active">
                <i class="fas fa-tachometer-alt"></i> Dashboard
            </a></li>
            <li><a href="bookings.php">
                <i class="fas fa-calendar-check"></i> Bookings
            </a></li>
            <li><a href="Rooms.php">
                <i class="fas fa-bed"></i> Rooms
            </a></li>
            <li><a href="customers.php">
                <i class="fas fa-users"></i> Customers
            </a></li>
            <li><a href="reports.php">
                <i class="fas fa-chart-bar"></i> Reports
            </a></li>
        </ul>
    </div>

    <!-- MAIN CONTENT -->
    <div class="main-content">
        <div class="topbar">
            <h1>📊 Dashboard</h1>
            <div style="display: flex; align-items: center; gap: 20px;">
                <span class="user-greeting">👋 Welcome,Dharmik </span>   <!--  <?php echo $_SESSION['admin']; ?>-->
                <a href="logout.php" class="logout-btn">Logout</a>
            </div>
        </div>

        <div class="content">
            <?php echo $successMsg; ?>

            <h2>📈 Overview Statistics</h2>

            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-label">Total Bookings</div>
                    <div class="stat-value"><?php echo $totalBookings; ?></div>
                </div>
                <div class="stat-card">
                    <div class="stat-label">Total Rooms</div>
                    <div class="stat-value"><?php echo $totalRooms; ?></div>
                </div>
                <div class="stat-card revenue">
                    <div class="stat-label">Total Revenue</div>
                    <div class="stat-value">₹<?php echo number_format($totalRevenue); ?></div>
                </div>
                <div class="stat-card pending">
                    <div class="stat-label">Pending Payments</div>
                    <div class="stat-value"><?php echo $pendingPayments; ?></div>
                </div>
            </div>

<div class="table-container">
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Guest</th>
                <th>Email</th>
                <th>Check-in</th>
                <th>Check-out</th>
                <th>Amount</th>
                <th>Mode</th>
                <th>Status</th>
                <th>Date</th>
                <th style="min-width: 220px;">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $result = mysqli_query($conn, "SELECT * FROM bookings ORDER BY created_at DESC LIMIT 10");
            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
            ?>
            <tr>
                <td><strong>#<?php echo $row['id']; ?></strong></td>
               <td class="truncate" title="<?php echo htmlspecialchars($row['guest_name']); ?>">
    				<?php echo htmlspecialchars($row['guest_name']); ?>
				</td>
               <td class="truncate" title="<?php echo htmlspecialchars($row['email']); ?>">
    				<?php echo htmlspecialchars($row['email']); ?>
				</td>
                <td><?php echo date('d/m', strtotime($row['checkin'])); ?></td>
                <td><?php echo date('d/m', strtotime($row['checkout'])); ?></td>
                <td><strong>₹<?php echo number_format($row['total_amount']); ?></strong></td>
                <td class="truncate" title="<?php echo htmlspecialchars($row['payment_mode'] ?: 'Not Set'); ?>">
   					 <?php echo htmlspecialchars($row['payment_mode'] ?: '—'); ?>
				</td>
                <td>
                    <span class="status-badge <?php echo strtolower($row['payment_status']); ?>">
                        <?php echo $row['payment_status']; ?>
                    </span>
                </td>
                <td><?php echo date("d M", strtotime($row['created_at'])); ?></td>
                <td style="white-space: normal;">
                    <div class="action-buttons">
                        <a class="action-btn edit" href="edit_booking.php?id=<?php echo $row['id']; ?>">Edit</a>
                        <a class="action-btn delete" onclick="return confirm('Delete booking #<?php echo $row['id']; ?>?')" href="delete_booking.php?id=<?php echo $row['id']; ?>">Delete</a>
                        <a class="action-btn invoice" target="_blank" href="invoice.php?id=<?php echo $row['id']; ?>">Invoice</a>
                    </div>
                </td>
            </tr>
            <?php 
                }
            } else {
            ?>
            <tr>
                <td colspan="10" style="padding: 40px; text-align: center; color: #94a3b8;">
                    <i class="fas fa-inbox" style="font-size: 48px; margin-bottom: 15px; opacity: 0.5;"></i>
                    <div>No bookings found</div>
                </td>
            </tr>
            <?php } ?>
        </tbody>
    </table>
</div>

            <div class="footer">
                © 2026 Hotel Banyan Paradise Kitchen | Admin Panel by Dharmik Barot
            </div>
        </div>
    </div>

    <script>
    function toggleSidebar() {
        document.getElementById('sidebar').classList.toggle('open');
        document.querySelector('.sidebar-overlay').classList.toggle('active');
    }

    // Close sidebar on outside click
    document.addEventListener('click', function(e) {
        const sidebar = document.getElementById('sidebar');
        const hamburger = document.querySelector('.hamburger');
        if (!sidebar.contains(e.target) && !hamburger.contains(e.target)) {
            sidebar.classList.remove('open');
            document.querySelector('.sidebar-overlay').classList.remove('active');
        }
    });

    // Active menu
    document.querySelectorAll('.sidebar-menu a').forEach(link => {
        link.addEventListener('click', function() {
            document.querySelectorAll('.sidebar-menu a').forEach(l => l.classList.remove('active'));
            this.classList.add('active');
        });
    });
    </script>
</body>
</html>
