<?php
$success = false;
$booking_data = null;

$conn = mysqli_connect(
    "",
    "",
    "",
    ""
);

if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}

if (isset($_POST['submit'])) {

    $guest_name = $_POST['guest_name'];
    $email      = $_POST['email'];
    $checkin    = $_POST['checkin'];
    $checkout   = $_POST['checkout'];

    // STATIC VALUES (you can change later)
    $room_id = 1;
    $payment_status = "Pending";
    $payment_mode   = "Cash";

    $days = (strtotime($checkout) - strtotime($checkin)) / (60*60*24);
    if ($days <= 0) $days = 1;

    $total_amount = $days * 2500;

    $sql = "INSERT INTO bookings 
            (room_id, guest_name, email, checkin, checkout, total_amount, payment_status, payment_mode, created_at)
            VALUES 
            ('$room_id', '$guest_name', '$email', '$checkin', '$checkout', '$total_amount', '$payment_status', '$payment_mode', NOW())";

    if (mysqli_query($conn, $sql)) {
        $success = true;
        $booking_data = [
            'name' => $guest_name,
            'email' => $email,
            'checkin' => date('F j, Y', strtotime($checkin)),
            'checkout' => date('F j, Y', strtotime($checkout)),
            'days' => $days,
            'total' => $total_amount
        ];
    } else {
        die("Insert Error: " . mysqli_error($conn));
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking Confirmed | Hotel Banyan Paradise Kitchen</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;800&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        body {
            font-family: 'Poppins', sans-serif;
            min-height: 100vh;
            overflow-x: hidden;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            padding: 20px;
        }

        #confetti-canvas {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
            z-index: 1;
        }

        .success-container {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            padding: 50px 40px;
            width: 100%;
            max-width: 550px;
            text-align: center;
            border-radius: 25px;
            box-shadow: 0 30px 60px rgba(0,0,0,0.3);
            position: relative;
            z-index: 10;
            animation: bounceIn 1s ease-out;
        }

        .celebration-icon {
            width: 120px;
            height: 120px;
            margin: 0 auto 25px;
            background: linear-gradient(45deg, #ffd700, #ffed4a, #f39c12);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 4rem;
            box-shadow: 0 20px 40px rgba(255,215,0,0.4);
            animation: pulseGlow 2s ease-in-out infinite;
        }

        .success-title {
            font-size: clamp(2.2rem, 5vw, 3.5rem);
            font-weight: 800;
            background: linear-gradient(45deg, #2ecc71, #27ae60, #52be80);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin-bottom: 15px;
            animation: slideInUp 1s ease-out 0.2s both;
        }

        .success-subtitle {
            color: #555;
            font-size: 1.1rem;
            font-weight: 300;
            margin-bottom: 30px;
            animation: slideInUp 1s ease-out 0.4s both;
        }

        .booking-details {
            background: linear-gradient(135deg, #f8f9fa, #e9ecef);
            border-radius: 15px;
            padding: 25px;
            margin: 25px 0;
            text-align: left;
            animation: slideInUp 1s ease-out 0.6s both;
        }

        .detail-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px 0;
            border-bottom: 1px solid #e1e5e9;
        }

        .detail-row:last-child { border-bottom: none; }

        .detail-label { 
            color: #666; 
            font-weight: 500;
            font-size: 0.95rem;
        }

        .detail-value {
            font-weight: 600;
            color: #333;
            font-size: 1.1rem;
        }

        .total-amount {
            background: linear-gradient(45deg, #2ecc71, #27ae60);
            color: white;
            padding: 15px 25px;
            border-radius: 12px;
            font-size: 1.3rem;
            font-weight: 700;
            margin-top: 15px;
            animation: bounce 0.6s ease-out 1s both;
        }

        .btn-home {
            display: inline-block;
            margin-top: 30px;
            padding: 15px 40px;
            background: linear-gradient(45deg, #e63946, #d63031);
            color: white;
            text-decoration: none;
            border-radius: 12px;
            font-weight: 600;
            font-size: 1.1rem;
            transition: all 0.3s ease;
            box-shadow: 0 10px 25px rgba(230,57,70,0.3);
            animation: slideInUp 1s ease-out 0.8s both;
        }

        .btn-home:hover {
            transform: translateY(-3px);
            box-shadow: 0 15px 35px rgba(230,57,70,0.4);
        }

        @keyframes bounceIn {
            0% { opacity: 0; transform: scale(0.3) rotate(-10deg); }
            50% { opacity: 0.8; transform: scale(1.05) rotate(2deg); }
            70% { transform: scale(0.98) rotate(-1deg); }
            100% { opacity: 1; transform: scale(1) rotate(0deg); }
        }

        @keyframes pulseGlow {
            0%, 100% { box-shadow: 0 20px 40px rgba(255,215,0,0.4); transform: scale(1); }
            50% { box-shadow: 0 0 50px rgba(255,215,0,0.8); transform: scale(1.05); }
        }

        @keyframes slideInUp {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes bounce {
            0%, 20%, 50%, 80%, 100% { transform: translateY(0); }
            40% { transform: translateY(-10px); }
            60% { transform: translateY(-5px); }
        }

        @media (max-width: 480px) {
            .success-container { padding: 30px 20px; margin: 10px; }
            .celebration-icon { width: 90px; height: 90px; font-size: 3rem; }
        }
    </style>
</head>
<body>
    <canvas id="confetti-canvas"></canvas>

    <?php if ($success && $booking_data): ?>
        <div class="success-container">
            <div class="celebration-icon">🎉</div>
            <h1 class="success-title">Booking Confirmed!</h1>
            <p class="success-subtitle">
                Congratulations <strong><?php echo htmlspecialchars($booking_data['name']); ?></strong>!<br>
                Your reservation is secured.
            </p>

            <div class="booking-details">
                <div class="detail-row">
                    <span class="detail-label">Booking ID:</span>
                    <span class="detail-value">#<?php echo $booking_data['booking_id']; ?></span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Check-in:</span>
                    <span class="detail-value"><?php echo $booking_data['checkin']; ?></span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Check-out:</span>
                    <span class="detail-value"><?php echo $booking_data['checkout']; ?></span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Duration:</span>
                    <span class="detail-value"><?php echo $booking_data['days']; ?> nights</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Guests:</span>
                    <span class="detail-value"><?php echo $booking_data['guests']; ?></span>
                </div>
                <div class="total-amount">
                    Total: ₹<?php echo number_format($booking_data['total']); ?>
                </div>
            </div>

          <a href="https://hotel-management13.kesug.com/" class="btn-home">← Back to Home</a>
        </div>

        <script>
            function createConfetti() {
                const canvas = document.getElementById('confetti-canvas');
                const ctx = canvas.getContext('2d');
                canvas.width = window.innerWidth;
                canvas.height = window.innerHeight;

                const confetti = [];
                const colors = ['#ffd700', '#ff6b6b', '#4ecdc4', '#45b7d1', '#f9ca24', '#6c5ce7'];

                for (let i = 0; i < 100; i++) {
                    confetti.push({
                        x: Math.random() * canvas.width,
                        y: Math.random() * canvas.height - canvas.height,
                        r: Math.random() * 6 + 2,
                        d: Math.random() * 10 + 5,
                        color: colors[Math.floor(Math.random() * colors.length)],
                        tilt: Math.random() * 10,
                        tiltAngle: 0
                    });
                }

                function draw() {
                    ctx.clearRect(0, 0, canvas.width, canvas.height);
                    confetti.forEach((c) => {
                        c.tiltAngle += 0.1;
                        c.y += c.d;
                        c.tilt = Math.sin(c.tiltAngle) * 15;

                        if (c.y > canvas.height) {
                            c.x = Math.random() * canvas.width;
                            c.y = -10;
                        }

                        ctx.beginPath();
                        ctx.lineWidth = c.r;
                        ctx.strokeStyle = c.color;
                        ctx.moveTo(c.x + c.tilt + c.r / 2, c.y);
                        ctx.lineTo(c.x + c.tilt - c.r / 2, c.y + c.tilt + c.r / 2);
                        ctx.stroke();
                    });
                    requestAnimationFrame(draw);
                }
                draw();
            }

            window.addEventListener('load', createConfetti);
        </script>
    <?php else: ?>
        <div class="success-container">
            <div style="font-size: 4rem; color: #e53e3e; margin-bottom: 20px;">⚠️</div>
            <h1 style="color: #e53e3e; font-size: 2.5rem;">Please complete the form</h1>
            <p style="color: #666; margin-bottom: 30px;">Fill all fields and try again.</p>
           <a href="https://hotel-management13.kesug.com/" class="btn-home">← Back to Home</a>
        </div>
     <div class="footer-bottom">
                <p>© 2026 Dharmik Barot. All Rights Reserved | Designed with ❤️ in Vadodara</p>
            </div>
    <?php endif; ?>
</body>
</html>
